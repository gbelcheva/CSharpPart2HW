﻿namespace Task04_Re_factor_and_improve_the_code
{
    using System;
    using System.Collections.Generic;

    public class MinesEngine
    {
        public static void PlayTurn(
            char[,] playingBoard,
            char[,] mines, 
            int row, 
            int column)
        {
            char numberOfMines = CountMines(mines, row, column);
            mines[row, column] = numberOfMines;
            playingBoard[row, column] = numberOfMines;
        }

        public static char[,] CreatePlayingBoard()
        {
            int boardRows = 5;
            int boardColumns = 10;
            char[,] playingBoard = new char[boardRows, boardColumns];

            for (int i = 0; i < boardRows; i++)
            {
                for (int j = 0; j < boardColumns; j++)
                {
                    playingBoard[i, j] = '?';
                }
            }

            return playingBoard;
        }

        public static char[,] PlaceMines()
        {
            int rows = 5;
            int columns = 10;
            char[,] playingBoard = new char[rows, columns];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    playingBoard[i, j] = '-';
                }
            }

            List<int> minesList = new List<int>();

            while (minesList.Count < 15)
            {
                Random random = new Random();
                int minePosition = random.Next(50);
                if (!minesList.Contains(minePosition))
                {
                    minesList.Add(minePosition);
                }
            }

            foreach (int mine in minesList)
            {
                int row = mine % columns;
                int column = mine / columns;

                if (row == 0 && mine != 0)
                {
                    column--;
                    row = columns;
                }
                else
                {
                    row++;
                }

                playingBoard[column, row - 1] = '*';
            }

            return playingBoard;
        }

        private static char CountMines(char[,] board, int rows, int columns)
        {
            int counter = 0;
            int totalRows = board.GetLength(0);
            int totalColumns = board.GetLength(1);

            if (rows - 1 >= 0)
            {
                if (board[rows - 1, columns] == '*')
                {
                    counter++;
                }
            }

            if (rows + 1 < totalRows)
            {
                if (board[rows + 1, columns] == '*')
                {
                    counter++;
                }
            }

            if (columns - 1 >= 0)
            {
                if (board[rows, columns - 1] == '*')
                {
                    counter++;
                }
            }

            if (columns + 1 < totalColumns)
            {
                if (board[rows, columns + 1] == '*')
                {
                    counter++;
                }
            }

            if ((rows - 1 >= 0) && (columns - 1 >= 0))
            {
                if (board[rows - 1, columns - 1] == '*')
                {
                    counter++;
                }
            }

            if ((rows - 1 >= 0) && (columns + 1 < totalColumns))
            {
                if (board[rows - 1, columns + 1] == '*')
                {
                    counter++;
                }
            }

            if ((rows + 1 < totalRows) && (columns - 1 >= 0))
            {
                if (board[rows + 1, columns - 1] == '*')
                {
                    counter++;
                }
            }

            if ((rows + 1 < totalRows) && (columns + 1 < totalColumns))
            {
                if (board[rows + 1, columns + 1] == '*')
                {
                    counter++;
                }
            }

            return char.Parse(counter.ToString());
        }
    }
}