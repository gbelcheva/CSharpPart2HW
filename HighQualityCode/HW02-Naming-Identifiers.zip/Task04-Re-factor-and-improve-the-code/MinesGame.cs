﻿namespace Task04_Re_factor_and_improve_the_code
{
    using System;
    using System.Collections.Generic;

    public class MinesGame
    {
        public static void Main(string[] args)
        {
            const int MaxFields = 35;
            string command = string.Empty;
            char[,] playingBoard = MinesEngine.CreatePlayingBoard();
            char[,] mines = MinesEngine.PlaceMines();
            int counter = 0;
            List<Player> topPlayers = new List<Player>(6);
            int row = 0;
            int column = 0;
            bool isNewGame = true;
            bool isWinner = false;
            bool isGameOver = false;

            do
            {
                if (isNewGame)
                {
                    Console.WriteLine("Lets play Mines. Try to step on fields while avoiding the mines." +
                    " Show high scores with command 'top', start new game with 'restart', quit game with 'exit'!");
                    MinesConsoleRenderer.OutputBoard(playingBoard);
                    isNewGame = false;
                }

                Console.Write("Input row and column: ");
                command = Console.ReadLine().Trim();
                if (command.Length >= 3)
                {
                    if (int.TryParse(command[0].ToString(), out row) &&
                    int.TryParse(command[2].ToString(), out column) &&
                        row <= playingBoard.GetLength(0) && column <= playingBoard.GetLength(1))
                    {
                        command = "turn";
                    }
                }

                switch (command)
                {
                    case "top":
                        MinesConsoleRenderer.OutputScoreBoard(topPlayers);
                        break;
                    case "restart":
                        playingBoard = MinesEngine.CreatePlayingBoard();
                        mines = MinesEngine.PlaceMines();
                        MinesConsoleRenderer.OutputBoard(playingBoard);
                        isGameOver = false;
                        isNewGame = false;
                        break;
                    case "exit":
                        Console.WriteLine("Goodbye!");
                        break;
                    case "turn":
                        if (mines[row, column] != '*')
                        {
                            if (mines[row, column] == '-')
                            {
                                MinesEngine.PlayTurn(playingBoard, mines, row, column);
                                counter++;
                            }

                            if (MaxFields == counter)
                            {
                                isWinner = true;
                            }
                            else
                            {
                                MinesConsoleRenderer.OutputBoard(playingBoard);
                            }
                        }
                        else
                        {
                            isGameOver = true;
                        }

                        break;
                    default:
                        Console.WriteLine("\nWrong command.\n");
                        break;
                }

                if (isGameOver)
                {
                    MinesConsoleRenderer.OutputBoard(mines);
                    Console.Write(
                        "\nGame over, you stepped on a mine! You managed to score {0} points. " +
                        "Input nickname: ", 
                        counter);
                    string nickname = Console.ReadLine();
                    Player finalScore = new Player(nickname, counter);
                    if (topPlayers.Count < 5)
                    {
                        topPlayers.Add(finalScore);
                    }
                    else
                    {
                        for (int i = 0; i < topPlayers.Count; i++)
                        {
                            if (topPlayers[i].Points < finalScore.Points)
                            {
                                topPlayers.Insert(i, finalScore);
                                topPlayers.RemoveAt(topPlayers.Count - 1);
                                break;
                            }
                        }
                    }

                    topPlayers.Sort((Player stats1, Player stats2) => stats2.Name.CompareTo(stats1.Name));
                    topPlayers.Sort((Player stats1, Player stats2) => stats2.Points.CompareTo(stats1.Points));
                    MinesConsoleRenderer.OutputScoreBoard(topPlayers);

                    playingBoard = MinesEngine.CreatePlayingBoard();
                    mines = MinesEngine.PlaceMines();
                    counter = 0;
                    isGameOver = false;
                    isNewGame = true;
                }

                if (isWinner)
                {
                    Console.WriteLine("\nCongratilations! You stepped on all " + MaxFields + " fields without stepping on a mine.");
                    MinesConsoleRenderer.OutputBoard(mines);
                    Console.WriteLine("Input nickname: ");
                    string nickname = Console.ReadLine();
                    Player playerStats = new Player(nickname, counter);
                    topPlayers.Add(playerStats);
                    MinesConsoleRenderer.OutputScoreBoard(topPlayers);
                    playingBoard = MinesEngine.CreatePlayingBoard();
                    mines = MinesEngine.PlaceMines();
                    counter = 0;
                    isWinner = false;
                    isNewGame = true;
                }
            }
            while (command != "exit");
            Console.Read();
        }
    }
}